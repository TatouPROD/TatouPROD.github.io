# AutoDiggingBot for Club Penguin !
## Are-you ready to earn a quantity of coins that you never imagined ?!

### 3 languages avaible ! English, Español, Français.

-----------


ENGLISH
-----------

Welcome to the AutoDiggingBot! With it, you will earn more than 300,000 coins a night!

To use, execut 'AutoDiggingBot.exe', click on 'Drill now!', follow the instructions and just let the program run !
In few hours a lot of coins for you !

You can find the instructions inside the app, or watch the following video :
https://www.youtube.com/watch?v=7nwJVvcnlFg&t=126s

Earn a lot of coins! Comment the app! Share it! :)

-----------


ESPANOL
-----------
¡Bienvenido al AutoDiggingBot! ¡Con él, ganarás más de 300.000 coins en una noche!

Para usarlo; abre 'AutoDiggingBot.exe', haz clic en ¡Minar!, sigue la instrucción y deja el programa funcionar solo.
¡En unas horas, una montaña de coins para ti!

Puedes encontrar las instrucciónes en la aplicación, o ver el siguiente vídeo:
https://www.youtube.com/watch?v=7nwJVvcnlFg&t=126s

¡Gana mucho coins! ¡Comenta la aplicación! ¡Comparte la! :)

-----------



FRANCAIS
-----------
Bienvenue sur le AutoDiggingBot ! Avec lui, tu gagneras plus de 300 000 coins en une nuit !

Pour l'utiliser, lance 'AutoDiggingBot.exe', clique sur 'Viens miner !', suis les instructions et laisse le programme tourner tout seul.
Dans quelques heures, une montagne de coins sera à toi !

Tu peux trouver les instructions dans l'application, ou regarder la vidéo suivante :
https://www.youtube.com/watch?v=7nwJVvcnlFg&t=126s

Gagne beaucoup de coins ! Commente l'application ! Partage là ! :)

-----------





This is a free app.
©TatouPRODUCT©
